"""
========================================================================================
CAPA WEB Y CONTROLADOR HTTP NATIVO (PYTHON HTTP.SERVER - CERO DEPENDENCIAS)
Cátedra: Ingeniería de Software 3 [IF0129] - Uniremington
Provee API REST + Dashboard Web interactivo en tiempo real con Logging y Validaciones
========================================================================================
"""
import os
import json
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from src.repositories import SQLiteProductoRepository, SQLitePedidoRepository, SQLiteOutboxRepository
from src.services import ColmenaService, PasarelaPagosMock, SagaOrquestadorMatriculaPedido
from src.validators import ValidationError
from src.logger import get_logger

logger = get_logger("HTTP_Server")

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "LaColmena.db")

prod_repo = SQLiteProductoRepository(DB_PATH)
ped_repo = SQLitePedidoRepository(DB_PATH)
outbox_repo = SQLiteOutboxRepository(DB_PATH)
pasarela = PasarelaPagosMock()
Colmena_service = ColmenaService(prod_repo, ped_repo, outbox_repo)
saga_orquestador = SagaOrquestadorMatriculaPedido(Colmena_service, pasarela)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
with open(os.path.join(BASE, "la_colmena.html"), encoding="utf-8") as f:
    HTML_DASHBOARD = f.read()

class LaColmenaHTTPHandler(BaseHTTPRequestHandler):
    """
    Controlador HTTP Nativo (SoD - Plano de Presentación Web).
    Se encarga exclusivamente del parsing de solicitudes HTTP, enrutamiento,
    captura de errores de validación y serialización de respuestas JSON.
    """
    def log_message(self, format, *args):
        # Desviar los logs de acceso del servidor HTTP hacia nuestro logger estructurado
        logger.debug(f"{self.address_string()} - {format % args}")

    def do_GET(self):
        url_parsed = urllib.parse.urlparse(self.path)
        path = url_parsed.path

        if path in ["/", "/index.html"]:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_DASHBOARD.encode("utf-8"))

        elif path == "/api/productos":
            prods = Colmena_service.listar_catalogo()
            res = [p.__dict__ for p in prods]
            self._send_json(res)

        elif path == "/api/pedidos":
            peds = ped_repo.listar_todos()
            res = []
            for p in peds:
                d = p.__dict__.copy()
                d["estado"] = p.estado.value
                d["items"] = [it.__dict__ for it in p.items]
                res.append(d)
            self._send_json(res)

        elif path == "/api/outbox":
            pendientes = outbox_repo.obtener_pendientes()
            self._send_json(pendientes)

        else:
            self.send_error(404, "Ruta no encontrada")

    def do_POST(self):
        if self.path == "/api/pedidos/saga":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            
            try:
                data = json.loads(body.decode("utf-8"))
            except Exception as e:
                logger.error(f"Error parseando JSON de entrada: {e}")
                self._send_json({"exito": False, "error": f"JSON malformado: {str(e)}"}, status=400)
                return

            try:
                resultado = saga_orquestador.ejecutar_saga_pedido(
                    cliente_id=data.get("cliente_id", ""),
                    cliente_nombre=data.get("cliente_nombre", ""),
                    direccion=data.get("direccion", ""),
                    items_req=data.get("items", []),
                    idempotency_key=data.get("idempotency_key", ""),
                    simular_falla_pago=data.get("simular_falla", False)
                )

                res_json = {
                    "exito": resultado["exito"],
                    "log": resultado["log"]
                }
                if resultado.get("pedido"):
                    p_dict = resultado["pedido"].__dict__.copy()
                    p_dict["estado"] = resultado["pedido"].estado.value
                    p_dict["items"] = [it.__dict__ for it in resultado["pedido"].items]
                    res_json["pedido"] = p_dict

                self._send_json(res_json)

            except ValidationError as ve:
                logger.warning(f"Error de validación defensiva en petición POST: {ve}")
                self._send_json({
                    "exito": False,
                    "error": str(ve),
                    "campo": getattr(ve, "campo", ""),
                    "log": [f"❌ Error de Validación: {str(ve)}"]
                }, status=422)

            except Exception as ex:
                logger.error(f"Error inesperado en ejecución de Saga: {ex}")
                self._send_json({
                    "exito": False,
                    "error": str(ex),
                    "log": [f"🚨 Error Interno del Servidor: {str(ex)}"]
                }, status=500)
        else:
            self.send_error(404, "Endpoint no soportado")

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

def run_server(port: int = 8086):
    """Lanza el servidor HTTP nativo en el puerto especificado."""
    server = HTTPServer(("0.0.0.0", port), LaColmenaHTTPHandler)
    logger.info(f"🚀 Servidor LaColmena Web activo en: http://localhost:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Deteniendo servidor LaColmena limpiamente...")
        server.server_close()
